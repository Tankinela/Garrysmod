player_manager.AddValidModel( "Meredith Wage by Rinyata#7886", 				"models/rinyata/meredith/meredithwage.mdl" )
list.Set( "PlayerOptionsModel",  "Meredith Wage by Rinyata#7886",				"models/rinyata/meredith/meredithwage.mdl" )

